public class TabelaHashLinearEx10 {
    private Integer[] tabela;
    private int tamanho;
    private double fatorDeCarga;
    private static final Integer APAGADO = Integer.MIN_VALUE;

    public TabelaHashLinearEx10(){
        this.tabela = new Integer[11];
        this.tamanho = 0;
        this.fatorDeCarga = 0.75;
    }

    public int hash(int chave){
        return chave % this.tabela.length;
    }

    public Integer get(int chave){
        int sondagem = 0;
        int hash;
        
        while(sondagem < tabela.length){
            hash = (hash(chave) + sondagem) % tabela.length;
            if(tabela[hash] == null){
                return null;
            } else if(tabela[hash] == chave){
                return tabela[hash];
            } else{
                sondagem++;
            }
        }
        return null;
    }

    public void put(int elemento){
        if((double) this.tamanho / this.tabela.length >= this.fatorDeCarga || 
            this.tamanho == this.tabela.length){
            resize();    
        }
        int sondagem = 0;
        int hash = hash(elemento); 
        
        while(sondagem < tabela.length){ 
            hash = ( hash + sondagem) % tabela.length;
            if(tabela[hash] == null || tabela[hash] == elemento 
                || tabela[hash].equals(APAGADO)){
                tabela[hash] = elemento;
                this.tamanho++;
                return;
            }else{
                sondagem++;
            }
        }
        return;
    }

    public void resize(){
        Integer[] tabelaAntiga = this.tabela;
        this.tabela = new Integer[this.tabela.length * 2];
        this.tamanho = 0;

        for(Integer i : tabelaAntiga){
            if(i != null){
                this.put(i);
            }
        }
    }

    public Integer remove(int chave){
        int sondagem = 0;
        int hash;
        
        while(sondagem < tabela.length){
            hash = (hash(chave) + sondagem) % tabela.length;
            if(tabela[hash] == null){
                return null;
            } else if(tabela[hash] == chave){
                Integer i = tabela[hash];
                tabela[hash] = APAGADO;
                tamanho--;
                return i;
            } else{
                sondagem++;
            }
        }
        return null;
    }

    public void imprimir(){
        int i = 0;
        System.out.println("======== Tabela HASH ==========");
        for(Integer valor : this.tabela){
            System.out.print("Pos "+i+": ");
            if(valor == null){
                System.out.println("Vazio");
            }else if(valor.equals(APAGADO)) {
                System.out.println("APAGADO");
            }else{
                System.out.println(i);
            }
            i++;
        }
        System.out.println("======================= \n");
    }

    public static void main(String[] args) {
        TabelaHashLinearEx10 hashTable = new TabelaHashLinearEx10();

        // a. Inserindo elementos
        int[] elements = {52, 45, 64, 34, 69, 11, 10, 3, 6, 2};
        for (int element : elements) {
            hashTable.put(element);
        }
        hashTable.imprimir();

        // b. Buscar o elemento 45
        int searchKey1 = 45;
        System.out.println("Buscando " + searchKey1 + ": " + (hashTable.get(searchKey1) != null ? "Encontrado" : "Não encontrado"));


        // c. Buscar o elemento 75
        int searchKey2 = 75;
        System.out.println("Buscando " + searchKey2 + ": " + (hashTable.get(searchKey2) != null ? "Encontrado" : "Não encontrado"));

        // d. Remover o elemento 11 e imprimir tabela
        hashTable.remove(11);
        hashTable.imprimir();
    }
}
