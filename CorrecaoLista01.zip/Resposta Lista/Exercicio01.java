public class Exercicio01 {
    public static void main(String[] args) {
        int vetor[] = new int[100000];

        for(int i=0; i<vetor.length; i++){
            vetor[i] = (int) (Math.random()*10000);
        }

        //imprimirVetor(vetor);

        long tempoInicial = System.currentTimeMillis();
        int resultadoLinear = buscaLinearv2(vetor, 87);
        long tempoFinal = System.currentTimeMillis();

        long tempo = tempoFinal - tempoInicial;
        System.out.println("(LINEAR) Está na posição "+resultadoLinear);
        System.out.println("Tempo: "+ (tempo));
    }

    public static int buscaLinearv2(int[] vetor, int chave){
        int i=0;
        while(i<vetor.length){
            if(vetor[i] == chave){
                return i;
            }
            i++;
        }
        return -1;
    }
}
