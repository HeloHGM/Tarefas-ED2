import java.util.ArrayList;
import java.util.Arrays;

public class Exercicio02 {
    public static void main(String[] args) {
        int vetor[] = new int[10000];

        for(int i=0; i<vetor.length; i++){
            vetor[i] = (int) (Math.random()*10000);
        }

        //imprimirVetor(vetor);

        long tempoInicial = System.currentTimeMillis();
        ArrayList<Integer> resultadoLinear = buscaLinear(vetor, 87);
        long tempoFinal = System.currentTimeMillis();

        long tempo = tempoFinal - tempoInicial;
        System.out.println("(LINEAR) Está na posição "+resultadoLinear);
        System.out.println("Tempo: "+ (tempo));

        Arrays.sort(vetor);

        tempoInicial = System.currentTimeMillis();    
        ArrayList<Integer> resultadoBinário = buscaBinaria(vetor, 87);
        tempoFinal = System.currentTimeMillis();

        tempo = tempoFinal - tempoInicial;
        System.out.println("(BINÁRIO) Está na posição "+resultadoBinário);
        System.out.println("Tempo: "+ (tempo));


    }

    public static ArrayList<Integer> buscaLinear(int[] vetor, int chave){
        ArrayList<Integer> pos = new ArrayList<Integer>();
        for(int i=0; i<vetor.length; i++){
            if(vetor[i] == chave){
                pos.add(i);
            }
        }
        return pos;
    }

    public static ArrayList<Integer> buscaBinaria(int[] vetor, int chave){
        int posInicial = 0;
        int posFinal = vetor.length -1;
        ArrayList<Integer> pos = new ArrayList<Integer>();

        while(posInicial <= posFinal){
            int meio = (posInicial + posFinal) / 2;

            if(vetor[meio] == chave){
                pos.add(meio);
                int auxSup = meio+1;
                int auxInf = meio-1;

                while(vetor[auxSup] == chave){
                    pos.add(auxSup);
                    auxSup++;
                }
            
                while(vetor[auxInf] == chave){
                    pos.add(auxInf);
                    auxInf--;
                }

                return pos;
            }else if(vetor[meio] > chave){
                posFinal = meio-1;
                
            } else if(vetor[meio] < chave){
                posInicial = meio+1;
            }
        }

        return pos;
    }
        
}
