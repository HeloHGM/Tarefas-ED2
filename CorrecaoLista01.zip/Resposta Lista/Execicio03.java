import java.util.Arrays;

public class Execicio03{
    public static void main(String[] args) {
        int vetor[] = new int[100000];

        for(int i=0; i<vetor.length; i++){
            vetor[i] = (int) (Math.random()*10000);
        }

        //imprimirVetor(vetor);

        long tempoInicial = System.currentTimeMillis();
        int resultadoLinear = buscaLinear(vetor, 87);
        long tempoFinal = System.currentTimeMillis();

        long tempo = tempoFinal - tempoInicial;
        System.out.println("(LINEAR) Está na posição "+resultadoLinear);
        System.out.println("Tempo: "+ (tempo));
        
    }

    public static int buscaLinear(int[] vetor, int chave){
        for(int i=0; i<vetor.length; i++){
            if(vetor[i] == chave){
                return i;
            }
        }
        return -1;
    }

    public static void imprimirVetor(int[] vetor){
        System.out.print("[ ");
        for(int i=0; i<vetor.length-1; i++){
            System.out.print(vetor[i]+", ");
        }
        System.out.println(vetor[vetor.length-1]+" ]");
        
    }
}