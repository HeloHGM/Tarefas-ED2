import java.util.Arrays;

public class Execicio04{
    public static void main(String[] args) {
        int vetor[] = new int[100000];

        for(int i=0; i<vetor.length; i++){
            vetor[i] = (int) (Math.random()*10000);
        }

        Arrays.sort(vetor);

        long tempoInicial = System.currentTimeMillis();    
        int resultadoBinário = buscaBinaria(vetor, 87);
        long tempoFinal = System.currentTimeMillis();

        long tempo = tempoFinal - tempoInicial;
        System.out.println("(BINÁRIO) Está na posição "+resultadoBinário);
        System.out.println("Tempo: "+ (tempo));

    


        
    }

    public static int buscaBinaria(int[] vetor, int chave){
        int posInicial = 0;
        int posFinal = vetor.length -1;

        while(posInicial <= posFinal){
            int meio = (posInicial + posFinal) / 2;

            if(vetor[meio] == chave) return meio;
            else if(vetor[meio] > chave){
                posFinal = meio-1;
                
            } else if(vetor[meio] < chave){
                posInicial = meio+1;
            }
        }
            return -1;
        }
        
    public static void imprimirVetor(int[] vetor){
        System.out.print("[ ");
        for(int i=0; i<vetor.length-1; i++){
            System.out.print(vetor[i]+", ");
        }
        System.out.println(vetor[vetor.length-1]+" ]");
        
    }
}