
public class TabelaCheiaException extends RuntimeException{

}
