import java.util.ArrayList;

class Exercicio01Sala{
    public static void main(String[] args) {
        int[] vetor = {1, 1, 3, 3, 4, 4, 4, 5, 6, 7};
        imprimirVetor(vetor);

        ArrayList retornoLinear = buscaSequencialV2(vetor, 1);
        System.out.println(retornoLinear);

        ArrayList retornoBinaria = buscaBinariaV2(vetor, 1);
        System.out.println(retornoBinaria);
    }

    public static int buscaSequencial(int[] vetor, int chave){
        for(int i=0; i<vetor.length; i++){
            if(vetor[i]==chave) return i;
        }
        return -1;
    }
    
    public static ArrayList<Integer> buscaSequencialV2(int[] vetor, int chave){
        ArrayList<Integer> posicoes = new ArrayList();
        for(int i=0; i<vetor.length; i++){
            if(vetor[i]==chave){
                posicoes.add(i);
            };
        }
        return posicoes;
    }
    
    public static int[] criarVetorPreenchido(int tamanho){
        int[] vetor = new int[tamanho];
        
        for(int i=0; i<vetor.length; i++){
            vetor[i] = (int) (Math.random()*100);
        }

        return vetor;
    }

    public static void imprimirVetor(int[] vetor){
        System.out.print("[ ");
        for(int i =0; i < vetor.length-1; i++){
            System.out.print(i+", ");
        }
        System.out.print(vetor[vetor.length-1]+" ]");
    }


    public static int buscaBinaria(int[] vetor, int chave){
        int posInicial = 0;
        int posFinal = vetor.length -1;

        while(posInicial <= posFinal){
            int meio = (posInicial + posFinal) / 2;

            if(vetor[meio] == chave) return meio;
            else if(vetor[meio] > chave){
                posFinal = meio-1;
                
            } else if(vetor[meio] < chave){
                posInicial = meio+1;
            }
        }
            return -1;
        }

        public static ArrayList<Integer> buscaBinariaV2(int[] vetor, int chave){
            int posInicial = 0;
            int posFinal = vetor.length -1;
            ArrayList<Integer> posicoes = new ArrayList<Integer>();
    
            while(posInicial <= posFinal){
                int meio = (posInicial + posFinal) / 2;
    
                if(vetor[meio] == chave){
                    posicoes.add(meio);
                    int ant = meio - 1;
                    int pos = meio + 1;

                    while(ant >= 0 && vetor[ant] == chave){
                        posicoes.add(ant);
                        ant--;
                    }

                    while(pos < vetor.length && vetor[pos] == chave){
                        posicoes.add(pos);
                        pos++;
                    }
                    return posicoes;
                }
                else if(vetor[meio] > chave){
                    posFinal = meio-1;
                    
                } else if(vetor[meio] < chave){
                    posInicial = meio+1;
                }
            }
                return posicoes;
        }
}