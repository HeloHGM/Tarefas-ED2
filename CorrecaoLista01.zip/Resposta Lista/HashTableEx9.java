import java.util.ArrayList;

public class HashTableEx9{
    private ArrayList<Integer>[] tabela;

    public HashTableEx9(){
        this.tabela = new ArrayList[11];
    }

    public int hash(int chave){
        return chave % this.tabela.length;
    }

    public Integer get(int chave){
        int hash = this.hash(chave); 
        ArrayList<Integer> numeros = this.tabela[hash];
        if(numeros == null){
            return null;
        }
        for(Integer i : numeros){
            if(i == chave){
                return i;
            }
        }
        return null;
    }


    public void put(Integer elemento){
        int hash = this.hash(elemento);
        ArrayList<Integer> numeros = this.tabela[hash];
        
        if(numeros == null){ 
            numeros = new ArrayList<Integer>();
            numeros.add(elemento); 
            this.tabela[hash] = numeros;
        }else{
            for(int i=0; i<numeros.size(); i++){
                if(numeros.get(i) == elemento){
                    numeros.set(i, elemento);
                    return;
                }
            }
            numeros.add(elemento);
        }
    }

    public Integer remove(int chave){
        int hash = this.hash(chave);
        ArrayList<Integer> numeros = this.tabela[hash];
        for(Integer atual : numeros){
            if(atual == chave){
                numeros.remove(atual); 
                return atual;
            }
        }
        return null;
    }

    public void imprimir(){
        int i = 0;
        System.out.println("======== Tabela HASH ==========");
        for(ArrayList<Integer> lista : tabela){
            System.out.print("Pos "+i+": ");
            if(lista == null){
                System.out.println("[]");
            }else{
                System.out.println(lista);
            }
            i++;
        }
        System.out.println("======================= \n");
    }

    public static void main(String[] args) {
        HashTableEx9 hashTable = new HashTableEx9();

        // a. Inserindo elementos
        int[] elements = {52, 45, 64, 34, 69, 11, 10, 3, 6, 2};
        for (int element : elements) {
            hashTable.put(element);
        }
        hashTable.imprimir();

        // b. Buscar o elemento 45
        int searchKey1 = 45;
        System.out.println("Buscando " + searchKey1 + ": " + (hashTable.get(searchKey1) != null ? "Encontrado" : "Não encontrado"));
        hashTable.imprimir();

        // c. Buscar o elemento 75
        int searchKey2 = 75;
        System.out.println("Buscando " + searchKey2 + ": " + (hashTable.get(searchKey2) != null ? "Encontrado" : "Não encontrado"));
        hashTable.imprimir();
        
        // d. Remover o elemento 11 e imprimir tabela
        hashTable.remove(11);
        hashTable.imprimir();
    }

    
}